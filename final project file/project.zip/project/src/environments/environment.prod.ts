export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD0mOddB02kAipoULwLAuLTNlW-gTSyStA",
    authDomain: "eshop-bd.firebaseapp.com",
    databaseURL: "https://eshop-bd.firebaseio.com",
    projectId: "eshop-bd",
    storageBucket: "eshop-bd.appspot.com",
    messagingSenderId: "342606774908",
    appId: "1:342606774908:web:d6cdc0ca0d21c9339bfff9",
    measurementId: "G-GM7W911VHM"
  }
};
